const slider = document.querySelector('.slider');
const slides = document.querySelectorAll('.slide');
const prevButton = document.querySelector('.prev');
const nextButton = document.querySelector('.next');

let currentSlide = 0;

prevButton.addEventListener('click', () => {
  currentSlide--;
  slider.scrollLeft = currentSlide * slides[0].offsetWidth;
});

nextButton.addEventListener('click', () => {
  currentSlide++;
  slider.scrollLeft = currentSlide * slides[0].offsetWidth;
});

slider.addEventListener('scroll', () => {
  currentSlide = Math.round(slider.scrollLeft / slides[0].offsetWidth);
});

// Make the slider draggable
slider.addEventListener('mousedown', (e) => {
  let startX = e.clientX;
  let scrollLeft = slider.scrollLeft;

  document.addEventListener('mousemove', (e) => {
    slider.scrollLeft = scrollLeft - (e.clientX - startX);
  });

  document.addEventListener('mouseup', () => {
    document.removeEventListener('mousemove', null, false);
  });
});