const carousel = document.getElementById('myCarousel');
const carouselInner = carousel.querySelector('.carousel-inner');
const carouselItems = carouselInner.children;
const carouselIndicators = carousel.querySelectorAll('.carousel-indicator');

let currentIndex = 0;

carouselIndicators.forEach((indicator, index) => {
  indicator.addEventListener('click', () => {
    currentIndex = index;
    updateCarousel();
  });
});

function updateCarousel() {
  for (let i = 0; i < carouselItems.length; i++) {
    carouselItems[i].classList.remove('active');
  }
  carouselItems[currentIndex].classList.add('active');

  for (let i = 0; i < carouselIndicators.length; i++) {
    carouselIndicators[i].classList.remove('active');
  }
  carouselIndicators[currentIndex].classList.add('active');
}

updateCarousel();

// Adicionei essa parte para fazer o carrossel mudar automaticamente a cada 5 segundos
setInterval(() => {
  currentIndex = (currentIndex + 1) % carouselItems.length;
  updateCarousel();
}, 5000);


