const express = require("express");
const router = express.Router();
const conexao = require("./conexao");

router.get('/excluir', (req, res) => {
    res.render('excluir');
  });

router.post('/excluir', (req, res) => {
    const cpff = req.body.cpff;
  
    const sqlConferirUsuario = 'DELETE FROM USUARIO WHERE DOC_USUARIO = ?';
    conexao.query(sqlConferirUsuario, [cpff], (erro, resultado) => {
      if (erro) {
        console.error("Erro ao consultar o usuário:", erro);
        res.status(500).send('Erro ao verificar usuário');
        return;
      }else {
        res.status(500).send('Excluído com sucesso');
        res.render('index');
      }
    });
  });

module.exports = router;