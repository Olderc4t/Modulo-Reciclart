const express = require("express");
const router = express.Router();
const app = express();
const conexao = require("./conexao");
const validarCPF = require('./validaCPF');
const validarCNPJ = require('./validaCNPJ');
const validaIdade = require('./validaIdade');
 
router.get('/login', (req, res) => {
  res.render('login');
});
 
// Rota para lidar com o envio do formulário de login
router.post('/login', (req, res) => {
  const { email, senha } = req.body;

  const sqlConferirUsuario = 'SELECT * FROM USUARIO WHERE EMAIL_USUARIO = ? AND SENHA_USUARIO = ?';
  conexao.query(sqlConferirUsuario, [email, senha], (erro, resultado) => {
    if (erro) {
      console.error("Erro ao consultar o usuário:", erro);
      res.status(500).send('Erro ao verificar usuário');
      return;
    }
 
    // Verifica se o usuário foi encontrado no banco de dados
    if (resultado.length > 0) {
      // Usuário encontrado, faça algo, como redirecionar para uma página de perfil
      res.render('index');
    } else {
      // Usuário não encontrado, exiba uma mensagem de erro ou redirecione para uma página de erro
      res.send('Usuário não encontrado. Verifique suas credenciais.');
    }
  });
});

 // Rota para renderizar o formulário de cadastro
router.get('/cadastro', (req, res) => {
    res.render('cadastro');
  });
  
// Rota para lidar com o envio do formulário de cadastro
router.post('/cadastro', (req, res) => {
  const { nome, email, senha, cpf, datanasc, celular, endereco, cidade, bairro, numero, uf, cep} = req.body;

  if (cpf.length == 11){
    if (validarCPF(cpf)) {
      console.log("CPF válido!");
  } else {
      console.log("CPF inválido!");
      console.error("Erro:", erro);
      res.status(500).send('CPF inválido');
      return;
  }
  }else if(cpf.length == 14){
    if (validarCNPJ(cpf)) {
      console.error('CNPJ válido.');
  } else {
      console.log('CNPJ inválido.');
      console.error("Erro:", erro);
      res.status(500).send('CNPJ inválido');
      return;
  }
  }else{
 console.error("Digite um documento válido!")
 res.status(500).send('Documento inválido');
 return;
  };


  if(cpf.length == 11){
    if (validaIdade(datanasc)) {
      console.log('maior de idade ok');
  } else {
      console.log('menor de idade não pode se cadastrar no site');
  }
  }else{
    any
  }

  const sqlInserirUsuario = 'INSERT INTO USUARIO (EMAIL_USUARIO, SENHA_USUARIO, NOME_USUARIO, DOC_USUARIO, DATA_NASC_USUARIO, CELULAR_USUARIO, LOGRADOURO_USUARIO, CIDADE_USUARIO, BAIRRO_USUARIO, NUMERO_CASA_USUARIO, UF_USUARIO, CEP_USUARIO ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  conexao.query(sqlInserirUsuario, [email, senha, nome, cpf, datanasc, celular, endereco, cidade, bairro, numero, uf, cep], (erro, resultado) => {
    if (erro){
      console.error("Erro ao inserir o usuário:", erro);
      res.status(500).send('Erro ao cadastrar usuário');
      return;
    }
    console.log("Usuário inserido com sucesso!");
    res.render('index');
  });
});

//CADASTRO PRODUTO---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
router.get('/cadastroProduto', (req, res) => {
  res.render('cadastroProduto');
});

router.post('/cadastroProduto', async (req, res) => {
  const { nomeProduto, categ, estoque, descricao, preco, entrega} = req.body;
  const status = "a";


  const sqlInserirProduto = 'INSERT INTO PRODUTO (NOME_PRODUTO, TIPO_RECICLAVEL, QNTD_PRODUTO, DESCRICAO_PRODUTO, PRECO_PRODUTO, PRONTA_ENTREGA_PRODUTO, STATUS_PRODUTO ) VALUES (?, ?, ?, ?, ?, ?, ?)';
  await  conexao.query(sqlInserirProduto, [ nomeProduto, categ, estoque, descricao, preco, entrega, status], (erro, resultado) => {
    if (erro){
      console.error("Erro ao inserir o produto:", erro);
      res.status(500).send('Erro ao cadastrar produto');
      return;
    }
    console.log("Produto inserido com sucesso!");
    res.render('index');
  });

});

 
 
module.exports = router;