function validarCNPJ(cpf) {
    cpf = cpf.replace(/[^\d]/g, ''); // Remove caracteres não numéricos

    if (cpf.length !== 14) return false; // Verifica se o CNPJ tem 14 dígitos

    // Verifica se todos os dígitos são iguais, o que não é permitido em um CNPJ válido
    const igual = cpf.split('').every(digit => digit === cpf[0]);
    if (igual) return false;

    // Algoritmo de validação de CNPJ
    var tamanho = cpf.length - 2;
    var numeros = cpf.substring(0, tamanho);
    var digitos = cpf.substring(tamanho);
    var soma = 0;
    var pos = tamanho - 7;

    for (var i = tamanho; i >= 1; i--) {
        soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
        if (pos < 2) pos = 9;
    }

    var resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);

    if (resultado !== parseInt(digitos.charAt(0))) return false;

    tamanho = tamanho + 1;
    numeros = cpf.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;

    for (var i = tamanho; i >= 1; i--) {
        soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
        if (pos < 2) pos = 9;
    }

    resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);

    if (resultado !== parseInt(digitos.charAt(1))) return false;

    return true; // CNPJ válido
}

module.exports = validarCNPJ;