const express = require("express");
const router = express.Router();
const conexao = require("./conexao");

// Rota para renderizar o formulário de cadastro
router.get('/cadastroProduto', (req, res) => {
  res.render('cadastroProduto');
});

// Rota para lidar com o envio do formulário de cadastro
router.post('/cadastroProduto', (req, res) => {
  const { nomeProduto, categ, estoque, descricao, preco, entrega} = req.body;
  const status = "a";


  const sqlInserirProduto = 'INSERT INTO PRODUTO (NOME_PRODUTO, TIPO_RECICLAVEL, QNTD_PRODUTO, DESCRICAO_PRODUTO, PRECO_PRODUTO, PRONTA_ENTREGA_PRODUTO, STATUS_PRODUTO ) VALUES (?, ?, ?, ?, ?, ?, ?)';
  conexao.query(sqlInserirProduto, [ nomeProduto, categ, estoque, descricao, preco, entrega, status], (erro, resultado) => {
    if (erro){
      console.error("Erro ao inserir o produto:", erro);
      res.status(500).send('Erro ao cadastrar produto');
      return;
    }
    console.log("Produto inserido com sucesso!");
    res.render('index');
  });

});

module.exports = router;