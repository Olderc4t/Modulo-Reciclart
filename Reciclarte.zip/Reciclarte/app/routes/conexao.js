const mysql = require('mysql');
const conexao = mysql.createConnection({
  host: 'reciclarte.mysql.uhserver.com',
  user: 'reciclarte',
  password: '1qa2ws3ed@@',
  database: 'reciclarte'
});

let retryCount = 5;

const connectWithRetry = () => {
  conexao.connect((err) => {
    if (err) {
      console.error('Error connecting to the database:', err);
      if (retryCount > 0) {
        console.log(`Retrying... Attempts left: ${retryCount}`);
        setTimeout(() => {
          retryCount--;
          connectWithRetry();
        }, 2000);
      } else {
        console.error('Max retries reached. Unable to connect to the database.');
      }
      return;
    }
    console.log('Connected to the database');
  });
};

conexao.on('error', (err) => {
  if (err.code === 'ECONNRESET') {
    console.error('Connection was reset:', err);
    // Implement retry logic or other handling as needed
    if (retryCount > 0) {
      console.log(`Retrying connection... Attempts left: ${retryCount}`);
      setTimeout(() => {
        retryCount--;
        connectWithRetry();
      }, 2000);
    } else {
      console.error('Max retries reached. Unable to reconnect to the database.');
    }
  } else {
    console.error('Database error:', err);
  }
});

connectWithRetry();

module.exports = conexao;