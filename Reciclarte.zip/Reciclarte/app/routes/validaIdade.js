function validaIdade(datanasc) {
    const hoje = new Date();
    const nascimento = new Date(datanasc);
    const idade = hoje.getFullYear() - nascimento.getFullYear();

    // Verifica se a data de nascimento já ocorreu este ano
    const jaPassouAniversario = hoje.getMonth() > nascimento.getMonth() ||
        (hoje.getMonth() === nascimento.getMonth() && hoje.getDate() >= nascimento.getDate());

    if (jaPassouAniversario) {
        return idade >= 18;
    } else {
        return idade >= 19; // Se o aniversário ainda não ocorreu este ano, precisa ter pelo menos 19 anos
    }
}

 module.exports = validaIdade;