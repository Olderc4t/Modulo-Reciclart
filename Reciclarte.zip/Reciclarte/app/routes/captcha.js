const captchaImagens = ['./assets/img/captcha2.jpg', './assets/img/captcha3.png', './assets/img/captcha4.png"' ];
const captchaText = ['thrand', 'texto1', 'texto2']; 

// var imagem = document.getElementById("captchaImage");

function refreshCaptcha() {
    
    var randomIndex = Math.floor(Math.random() * captchaImagens.length);
    //imagem.src = captchaImagens[randomIndex];
    const captchaData = {
        imagem: captchaImagens[randomIndex],
        texto: captchaText[randomIndex]
    
    };
    return captchaData;
}

function validateCaptcha(userInput, correctText) {
    return userInput.trim().toLowerCase() === correctText;
}

// function validateCaptcha() {
//     var userInput = document.getElementById('texto').value.trim().toLowerCase(); 
//     var correctText = captchaText[randomIndex]; 
    
//     if (userInput === correctText) {
//         alert('Captcha válido!');
//     } else {
//         alert('Captcha inválido! Por favor, tente novamente.'); 
        
//     }
// }

module.exports = { validateCaptcha, refreshCaptcha };
