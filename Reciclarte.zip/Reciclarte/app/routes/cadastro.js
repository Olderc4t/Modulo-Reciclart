const express = require("express");
const router = express.Router();
const conexao = require("./conexao");
const validarCPF = require('./validaCPF');
const validarCNPJ = require('./validaCNPJ');
const validaIdade = require('./validaIdade');

// Rota para renderizar o formulário de cadastro
router.get('/cadastro', (req, res) => {
  res.render('cadastro');
});

// Rota para lidar com o envio do formulário de cadastro
router.post('/cadastro', (req, res) => {
  const { nome, email, senha, cpf, datanasc, celular, endereco, cidade, bairro, numero, uf, cep} = req.body;

  if (cpf.length == 11){
    if (validarCPF(cpf)) {
      console.log("CPF válido!");
  } else {
      console.log("CPF inválido!");
      console.error("Erro:", erro);
      res.status(500).send('CPF inválido');
      return;
  }
  }else if(cpf.length == 14){
    if (validarCNPJ(cpf)) {
      console.error('CNPJ válido.');
  } else {
      console.log('CNPJ inválido.');
      console.error("Erro:", erro);
      res.status(500).send('CNPJ inválido');
      return;
  }
  }else{
 console.error("Digite um documento válido!")
 res.status(500).send('Documento inválido');
 return;
  };
  
  if(cpf.length == 11){
    if (validaIdade(datanasc)) {
      console.log('maior de idade ok');
  } else {
      console.log('menor de idade não pode se cadastrar no site');
  }
  }else{
    any
  }


  const sqlInserirUsuario = 'INSERT INTO USUARIO (EMAIL_USUARIO, SENHA_USUARIO, NOME_USUARIO, DOC_USUARIO, DATA_NASC_USUARIO, CELULAR_USUARIO, LOGRADOURO_USUARIO, CIDADE_USUARIO, BAIRRO_USUARIO, NUMERO_CASA_USUARIO, UF_USUARIO, CEP_USUARIO ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  conexao.query(sqlInserirUsuario, [email, senha, nome, cpf, datanasc, celular, endereco, cidade, bairro, numero, uf, cep], (erro, resultado) => {
    if (erro){
      console.error("Erro ao inserir o usuário:", erro);
      res.status(500).send('Erro ao cadastrar usuário');
      return;
    }
    console.log("Usuário inserido com sucesso!");
    res.render('index');
  });

});

module.exports = router;
