const express = require("express");
const app = express();
const router = require("./app/routes/router");
const bodyParser = require('body-parser');

const port = 3001;

// Configuração do EJS como mecanismo de visualização
app.set('view engine', 'ejs');
app.set('views', __dirname + '/view'); // Define o diretório de visualização

app.use('/assets/style', function(req, res, next) {
  res.setHeader('Content-Type', 'text/css');
  next();
});

// Middleware para servir arquivos estáticos (CSS, JavaScript, imagens) da pasta login
app.use('/assets', express.static(__dirname + '/view/assets'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.get('/index', (req, res) => {
  res.render('index'); 
});

// Rotas
app.use("/", router);

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor ouvindo na porta ${port}\nhttp://localhost:${port}/index`);
});
